package com.yobitrust.HachCovid19Back;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HachCovid19BackApplication {

	public static void main(String[] args) {
		SpringApplication.run(HachCovid19BackApplication.class, args);
	}

}
