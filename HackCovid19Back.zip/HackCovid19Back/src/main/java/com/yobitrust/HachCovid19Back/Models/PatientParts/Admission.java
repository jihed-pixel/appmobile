package com.yobitrust.HachCovid19Back.Models.PatientParts;

public class Admission {
}
