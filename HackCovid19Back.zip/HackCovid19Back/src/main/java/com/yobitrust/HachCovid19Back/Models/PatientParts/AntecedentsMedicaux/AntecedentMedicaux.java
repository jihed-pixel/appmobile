package com.yobitrust.HachCovid19Back.Models.PatientParts.AntecedentsMedicaux;

public class AntecedentMedicaux {
}
