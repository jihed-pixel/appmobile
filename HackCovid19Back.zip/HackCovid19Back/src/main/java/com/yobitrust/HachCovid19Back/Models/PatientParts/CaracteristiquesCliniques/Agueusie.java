package com.yobitrust.HachCovid19Back.Models.PatientParts.CaracteristiquesCliniques;

import com.yobitrust.HachCovid19Back.Models.PatientParts.CaracCliniques;

import java.util.Date;

public class Agueusie  extends Symptome {
    public Agueusie(Date dateD, Date dateF) {
        super(dateD,dateF);
    }

    public Agueusie() {
        super();
    }
}
