package com.yobitrust.HachCovid19Back.Models.PatientParts.CaracteristiquesCliniques;

import com.yobitrust.HachCovid19Back.Models.PatientParts.CaracCliniques;

import java.util.Date;

public class Anosmie extends Symptome {
    public Anosmie(Date dateD, Date dateF) {
        super(dateD,dateF);
    }

    public Anosmie() {
        super();
    }
}
