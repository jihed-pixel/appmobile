package com.yobitrust.HachCovid19Back.Models.PatientParts.CaracteristiquesCliniques;

import com.yobitrust.HachCovid19Back.Models.PatientParts.CaracCliniques;

import java.util.Date;

public class AshthFat  extends Symptome {
    public AshthFat(Date dateD, Date dateF) {
        super(dateD,dateF);
    }

    public AshthFat() {
        super();
    }

}
