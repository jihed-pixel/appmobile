package com.yobitrust.HachCovid19Back.Models.PatientParts.CaracteristiquesCliniques;

import java.util.Date;

public class Cephalees  extends Symptome{

    public Cephalees(Date dateD, Date dateF) {
      super(dateD,dateF);
    }

    public Cephalees() {
        super();
    }


}
