package com.yobitrust.HachCovid19Back.Models.PatientParts.CaracteristiquesCliniques;

import java.util.Date;

public class DouleurThora  extends  Symptome{
    public DouleurThora(Date dateD, Date dateF) {
        super(dateD,dateF);
    }

    public DouleurThora() {
        super();
    }
}
