package com.yobitrust.HachCovid19Back.Models.PatientParts.CaracteristiquesCliniques;

import com.yobitrust.HachCovid19Back.Models.PatientParts.CaracCliniques;

import java.util.Date;

public class Engelure extends Symptome {
    public Engelure(Date dateD, Date dateF) {
        super(dateD,dateF);
    }

    public Engelure() {
        super();
    }
}
