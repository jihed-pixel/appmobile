package com.yobitrust.HachCovid19Back.Models.PatientParts.CaracteristiquesCliniques;

import com.yobitrust.HachCovid19Back.Models.PatientParts.CaracCliniques;

import java.util.Date;

public class GeneRespi  extends Symptome {
    public GeneRespi(Date dateD, Date dateF) {
        super(dateD,dateF);
    }

    public GeneRespi() {
        super();
    }
}
