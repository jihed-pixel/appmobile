package com.yobitrust.HachCovid19Back.Models.PatientParts.CaracteristiquesCliniques;

import com.yobitrust.HachCovid19Back.Models.PatientParts.CaracCliniques;

import java.util.Date;

public class MyalCourba extends Symptome {
    public MyalCourba(Date dateD, Date dateF) {
        super(dateD,dateF);
    }

    public MyalCourba() {
        super();
    }

}
